var READTHEDOCS_DATA = {
    project: "python-docx",
    version: "latest",
    language: "en",
    programming_language: "py",
    subprojects: {},
    canonical_url: "https://python-docx.readthedocs.io/en/latest/",
    theme: "armstrong",
    builder: "sphinx",
    docroot: "/docs/",
    source_suffix: ".rst",
    api_host: "https://readthedocs.org",
    commit: "94623ff6",
    ad_free: false,

    global_analytics_code: 'UA-17997319-1',
    user_analytics_code: null
};

